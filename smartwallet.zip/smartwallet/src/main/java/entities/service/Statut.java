package entities.service;

public enum Statut {
    DISPONIBLE,
    NON_DISPONIBLE
}
