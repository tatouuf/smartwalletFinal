package entities.service;

public enum TypeService {
    voiture,
    standard, maison
}
