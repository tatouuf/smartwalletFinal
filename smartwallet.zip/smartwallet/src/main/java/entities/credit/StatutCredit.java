
package entities.credit;

public enum StatutCredit {
    NON_REMBOURSE,
    REMBOURSE,
    PARTIELLEMENT_REMBOURSE
}

