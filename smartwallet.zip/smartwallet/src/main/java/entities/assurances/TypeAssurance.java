package entities.assurances;

    public enum TypeAssurance {
        AUTO,
        SANTE,
        MAISON,
        VIE,
        HABITATION,
        AUTRE


}

