package entities.assurances;

public enum Statut {
    ACTIVE,
    INACTIVE
}
